package com.stalkersexe.client;

import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = StalkersMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (StalkerKind k : StalkerKind.values()) {
            event.registerEntityRenderer(ModEntities.TYPES.get(k).get(), StalkerRenderer::new);
        }
    }
}
