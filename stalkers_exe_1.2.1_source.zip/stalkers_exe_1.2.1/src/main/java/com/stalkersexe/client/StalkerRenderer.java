package com.stalkersexe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * Renderiza la criatura como un sprite vertical que siempre mira a la camara,
 * con animaciones procedurales: balanceo al acechar, parpadeo/glitch al ser mirado,
 * carrera con inclinacion y pulso al perseguir.
 */
public class StalkerRenderer extends EntityRenderer<StalkerEntity> {

    public StalkerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.4F;
    }

    @Override
    public ResourceLocation getTextureLocation(StalkerEntity e) {
        return new ResourceLocation(StalkersMod.MODID, "textures/entity/" + e.kind().texture + ".png");
    }

    @Override
    public void render(StalkerEntity e, float yaw, float partial, PoseStack pose, MultiBufferSource buffers, int light) {
        StalkerKind kind = e.kind();
        float t = e.tickCount + partial;
        int st = e.getAnimState();

        float bob = 0.0F;
        float sway = 0.0F;
        float scale = 1.0F;
        float lean = 0.0F;
        boolean glitch = false;

        switch (st) {
            case StalkerEntity.ANIM_WATCHED -> {
                glitch = ((int) t / 3) % 11 == 0;
                sway = glitch ? 0.12F * (((int) t % 2 == 0) ? 1.0F : -1.0F) : 0.0F;
            }
            case StalkerEntity.ANIM_CHASE -> {
                bob = Math.abs(Mth.sin(t * 0.9F)) * 0.18F;
                sway = Mth.sin(t * 0.45F) * 0.06F;
                scale = 1.0F + 0.05F * Mth.sin(t * 1.8F);
                lean = 12.0F;
                glitch = kind == StalkerKind.HUNTER_RUN && ((int) t / 2) % 9 == 0;
            }
            case StalkerEntity.ANIM_SEARCH -> {
                sway = Mth.sin(t * 0.12F) * 0.12F;
                bob = Mth.sin(t * 0.10F) * 0.03F;
            }
            default -> {
                bob = Mth.sin(t * 0.15F) * 0.04F;
                sway = Mth.sin(t * 0.07F) * 0.03F;
            }
        }

        float h = kind.height * scale;
        float w = h * 0.5F;

        pose.pushPose();
        float camYaw = Minecraft.getInstance().gameRenderer.getMainCamera().getYRot();
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - camYaw));
        pose.translate(sway, bob, 0.0F);
        pose.mulPose(Axis.XP.rotationDegrees(-lean));

        int bl = Math.max((light & 0xFFFF) >> 4, 6);
        int sl = (light >> 20) & 0xF;
        int l = LightTexture.pack(bl, sl);

        int r = 255;
        int g = glitch ? 110 : 255;
        int b = glitch ? 110 : 255;

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(e)));
        PoseStack.Pose last = pose.last();
        Matrix4f m = last.pose();
        Matrix3f n = last.normal();
        vertex(vc, m, n, -w, 0.0F, 0.0F, 0.0F, 1.0F, r, g, b, l);
        vertex(vc, m, n, w, 0.0F, 0.0F, 1.0F, 1.0F, r, g, b, l);
        vertex(vc, m, n, w, h, 0.0F, 1.0F, 0.0F, r, g, b, l);
        vertex(vc, m, n, -w, h, 0.0F, 0.0F, 0.0F, r, g, b, l);
        pose.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Matrix3f n, float x, float y, float z,
                               float u, float v, int r, int g, int b, int light) {
        vc.vertex(m, x, y, z)
                .color(r, g, b, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(n, 0.0F, 0.0F, 1.0F)
                .endVertex();
    }
}
