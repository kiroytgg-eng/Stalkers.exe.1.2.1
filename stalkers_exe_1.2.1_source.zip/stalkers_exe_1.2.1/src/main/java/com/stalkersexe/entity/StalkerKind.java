package com.stalkersexe.entity;

/** Los cuatro tipos de criatura. Cada uno tiene su textura, velocidad, vida, dano y altura propios. */
public enum StalkerKind {
    HUNTER("hunter", "hunter", 0.30, 40.0, 6.0f, 2.6f),
    STALKER("stalker", "stalker4", 0.34, 30.0, 5.0f, 2.4f),
    SEEKER("seeker", "treepeek3", 0.32, 34.0, 4.5f, 2.1f),
    HUNTER_RUN("hunter_run", "hunter_run", 0.50, 60.0, 14.0f, 2.8f);

    public final String id;
    public final String texture;
    public final double speed;
    public final double health;
    public final float damage;
    public final float height;

    StalkerKind(String id, String texture, double speed, double health, float damage, float height) {
        this.id = id;
        this.texture = texture;
        this.speed = speed;
        this.health = health;
        this.damage = damage;
        this.height = height;
    }

    public static StalkerKind byId(String s) {
        for (StalkerKind k : values()) {
            if (k.id.equalsIgnoreCase(s)) return k;
        }
        return null;
    }
}
