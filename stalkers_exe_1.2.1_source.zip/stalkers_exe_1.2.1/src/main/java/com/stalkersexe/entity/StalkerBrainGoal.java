package com.stalkersexe.entity;

import com.stalkersexe.server.NoiseTracker;
import com.stalkersexe.server.StalkerConfig;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * IA principal. Fases: STALK (acechar), CHASE (perseguir), SEARCH (buscar).
 * Todo escala con el ajuste de peligro (0-100).
 *  - HUNTER: se congela si lo miras; si apartas la vista tras mirarlo mucho, se lanza (lunge).
 *  - STALKER: teletransporte tras tu espalda; ralentiza al golpear.
 *  - SEEKER: sigue ruidos (picar, correr); ciega al golpear; se desliza lejos si lo golpeas.
 *  - HUNTER_RUN: persecucion directa muy rapida y letal.
 */
public class StalkerBrainGoal extends Goal {
    private enum Phase { STALK, CHASE, SEARCH }

    private final StalkerEntity mob;
    private Phase phase = Phase.STALK;
    private Player target;
    private Vec3 lastKnown;

    private int watchedTicks;
    private int unseenNear;
    private int chaseTicks;
    private int lostTicks;
    private int strikeCd;
    private int blinkCd = 200;
    private int lungeTicks;
    private int searchTicks;
    private int ambientCd = 100;
    private int chaseSoundCd;
    private int postStrike;
    private boolean wasWatched;

    public StalkerBrainGoal(StalkerEntity mob) {
        this.mob = mob;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    private double range(double d) {
        StalkerKind k = mob.kind();
        if (k == StalkerKind.HUNTER_RUN) return 160.0;
        return 28.0 + 44.0 * d + (k == StalkerKind.SEEKER ? 16.0 : 0.0);
    }

    private Player pickTarget() {
        double d = StalkerConfig.danger01();
        if (mob.getTargetPlayer() != null) {
            Player owner = mob.level().getPlayerByUUID(mob.getTargetPlayer());
            if (owner != null && owner.isAlive() && !owner.isCreative() && !owner.isSpectator()) return owner;
        }
        return mob.level().getNearestPlayer(mob.getX(), mob.getY(), mob.getZ(), range(d),
                EntitySelector.NO_CREATIVE_OR_SPECTATOR);
    }

    private boolean seekerHasNoise() {
        return mob.kind() == StalkerKind.SEEKER
                && NoiseTracker.nearest(mob.level(), mob.position(), 64.0) != null;
    }

    @Override
    public boolean canUse() {
        return pickTarget() != null || seekerHasNoise();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
        mob.setAnimState(StalkerEntity.ANIM_STALK);
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        StalkerKind kind = mob.kind();
        double d = StalkerConfig.danger01();
        boolean hostile = d > 0.0;

        if (strikeCd > 0) strikeCd--;
        if (blinkCd > 0) blinkCd--;
        if (ambientCd > 0) ambientCd--;
        if (lungeTicks > 0) lungeTicks--;
        if (chaseSoundCd > 0) chaseSoundCd--;
        if (postStrike > 0 && --postStrike == 0 && kind == StalkerKind.HUNTER_RUN) {
            mob.discard();
            return;
        }

        Player p = pickTarget();
        if (p == null) {
            // Sin jugador cerca: el Buscador sigue ruidos
            NoiseTracker.Noise n = NoiseTracker.nearest(mob.level(), mob.position(), 64.0);
            if (n != null) {
                mob.getNavigation().moveTo(n.pos().x, n.pos().y, n.pos().z, 0.9);
                mob.setAnimState(StalkerEntity.ANIM_SEARCH);
            }
            return;
        }
        target = p;
        lastKnown = p.position();
        double dist = mob.distanceTo(p);

        if (kind == StalkerKind.HUNTER_RUN && phase != Phase.CHASE) {
            phase = Phase.CHASE;
            mob.playLocal("hunt_run_warn", 1.5F, 1.0F);
        }
        if (!hostile) phase = Phase.STALK;

        switch (phase) {
            case STALK -> stalk(p, dist, d, kind, hostile);
            case CHASE -> chase(p, dist, d, kind);
            case SEARCH -> search(p, dist, d, kind, hostile);
        }

        if (ambientCd <= 0 && dist < 30.0) {
            ambientCd = 400 + mob.getRandom().nextInt(400);
            switch (kind) {
                case HUNTER -> mob.playTo(p, "hunt_tension", 0.6F);
                case STALKER -> mob.playTo(p, "es_near", 0.7F);
                case SEEKER -> mob.playTo(p, "whispering", 0.7F);
                default -> { }
            }
        }
    }

    // ---------- ACECHAR ----------
    private void stalk(Player p, double dist, double d, StalkerKind kind, boolean hostile) {
        boolean watched = mob.isWatchedBy(p);
        double holdDist = Mth.lerp(d, 16.0, 5.0);
        mob.getLookControl().setLookAt(p, 30.0F, 30.0F);

        if (watched) {
            if (!wasWatched) {
                switch (kind) {
                    case HUNTER -> mob.playTo(p, "hunt_glance", 0.8F);
                    case STALKER -> mob.playTo(p, "es_glitch", 0.7F);
                    case SEEKER -> mob.playTo(p, "win_peek_spotted", 0.7F);
                    default -> { }
                }
            }
            watchedTicks++;
            unseenNear = 0;
            mob.getNavigation().stop();
            mob.setAnimState(StalkerEntity.ANIM_WATCHED);

            int limit = (int) Mth.lerp(d, 260.0, 70.0);
            if (hostile && dist < 26.0 && watchedTicks > limit) {
                startChase(p, kind);
                wasWatched = true;
                return;
            }
            if (hostile && blinkCd == 0) {
                if (kind == StalkerKind.STALKER && watchedTicks > 40) {
                    if (mob.blinkNear(p, 8.0, 14.0, true)) {
                        mob.playLocal("es_teleport", 1.0F, 1.0F);
                        blinkCd = (int) Mth.lerp(d, 400.0, 120.0);
                        watchedTicks = 0;
                    }
                } else if (kind == StalkerKind.SEEKER && watchedTicks > 60 && dist > 8.0) {
                    if (mob.blinkNear(p, 10.0, 16.0, false)) {
                        mob.playLocal("es_teleport", 0.8F, 0.7F);
                        blinkCd = (int) Mth.lerp(d, 500.0, 160.0);
                        watchedTicks = 0;
                    }
                }
            }
        } else {
            // Aparto la vista tras mirarlo mucho: el Hunter se lanza
            if (wasWatched && kind == StalkerKind.HUNTER && hostile && watchedTicks > 40 && dist < 20.0) {
                lungeTicks = 40;
                startChase(p, kind);
                wasWatched = false;
                return;
            }
            watchedTicks = Math.max(0, watchedTicks - 2);
            mob.setAnimState(StalkerEntity.ANIM_STALK);

            if (dist > holdDist) {
                mob.getNavigation().moveTo(p, 0.9 + 0.4 * d);
            } else {
                mob.getNavigation().stop();
                unseenNear++;
            }
            if (hostile && kind == StalkerKind.STALKER && blinkCd == 0 && dist > 9.0) {
                if (mob.blinkNear(p, 5.0, 9.0, true)) {
                    mob.playLocal("es_teleport", 1.0F, 1.2F);
                    blinkCd = (int) Mth.lerp(d, 400.0, 120.0);
                }
            }
            int ambush = (int) Mth.lerp(d, 700.0, 100.0);
            if (hostile && unseenNear > ambush) {
                startChase(p, kind);
            }
        }
        wasWatched = watched;
    }

    private void startChase(Player p, StalkerKind kind) {
        phase = Phase.CHASE;
        chaseTicks = 0;
        lostTicks = 0;
        chaseSoundCd = 0;
        switch (kind) {
            case HUNTER -> mob.playTo(p, "hunt_chase", 1.0F);
            case STALKER -> mob.playTo(p, "es_chase1", 1.0F);
            case SEEKER -> mob.playTo(p, "knock_scream", 0.9F);
            default -> { }
        }
    }

    // ---------- PERSEGUIR ----------
    private void chase(Player p, double dist, double d, StalkerKind kind) {
        chaseTicks++;
        mob.setAnimState(StalkerEntity.ANIM_CHASE);
        mob.getLookControl().setLookAt(p, 60.0F, 60.0F);
        mob.getNavigation().moveTo(p, lungeTicks > 0 ? 1.5 : 1.0);

        if (dist < 2.3 && strikeCd <= 0 && d > 0.0) {
            mob.strike(p, d);
            strikeCd = 20;
            if (kind == StalkerKind.HUNTER_RUN && postStrike == 0) postStrike = 30;
        }
        if (chaseSoundCd <= 0) {
            chaseSoundCd = kind == StalkerKind.HUNTER_RUN ? 30 : 100;
            if (kind == StalkerKind.HUNTER_RUN) mob.playTo(p, "hunt_run_pulse", 0.9F);
        }

        boolean los = mob.getSensing().hasLineOfSight(p);
        lostTicks = los ? 0 : lostTicks + 1;
        if (kind != StalkerKind.HUNTER_RUN) {
            if (lostTicks > (int) Mth.lerp(d, 100.0, 320.0)) {
                phase = Phase.SEARCH;
                searchTicks = 0;
            } else if (chaseTicks > (int) Mth.lerp(d, 400.0, 1600.0) && dist > 6.0) {
                phase = Phase.STALK;
                watchedTicks = 0;
                unseenNear = 0;
            }
        }
    }

    // ---------- BUSCAR ----------
    private void search(Player p, double dist, double d, StalkerKind kind, boolean hostile) {
        searchTicks++;
        mob.setAnimState(StalkerEntity.ANIM_SEARCH);
        if (hostile && dist < 22.0 && mob.getSensing().hasLineOfSight(p)) {
            startChase(p, kind);
            return;
        }
        Vec3 goal = lastKnown;
        if (kind == StalkerKind.SEEKER) {
            NoiseTracker.Noise n = NoiseTracker.nearest(mob.level(), mob.position(), 64.0);
            if (n != null) goal = n.pos();
        }
        if (goal != null) {
            mob.getNavigation().moveTo(goal.x, goal.y, goal.z, 0.9);
            if (mob.position().distanceTo(goal) < 2.5) searchTicks += 5;
        }
        if (searchTicks > 400) {
            phase = Phase.STALK;
            watchedTicks = 0;
            unseenNear = 0;
        }
    }
}
