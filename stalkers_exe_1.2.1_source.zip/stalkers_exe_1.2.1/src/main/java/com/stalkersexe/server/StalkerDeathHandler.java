package com.stalkersexe.server;

import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Cuando una criatura mata a un jugador, desaparece. */
@Mod.EventBusSubscriber(modid = StalkersMod.MODID)
public final class StalkerDeathHandler {

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity().level().isClientSide) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (event.getSource().getEntity() instanceof StalkerEntity stalker) {
            stalker.discard();
        }
    }

    private StalkerDeathHandler() {}
}
