package com.stalkersexe.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Arrays;

@Mod.EventBusSubscriber(modid = StalkersMod.MODID)
public final class StalkerCommand {

    private static final SuggestionProvider<CommandSourceStack> KINDS = (ctx, b) ->
            SharedSuggestionProvider.suggest(Arrays.stream(StalkerKind.values()).map(k -> k.id), b);

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> d = event.getDispatcher();
        d.register(Commands.literal("stalker")
                .requires(s -> s.hasPermission(2))
                .then(Commands.literal("help").executes(ctx -> help(ctx.getSource())))
                .then(Commands.literal("danger")
                        .executes(ctx -> showDanger(ctx.getSource()))
                        .then(Commands.argument("value", IntegerArgumentType.integer(0, 100))
                                .executes(ctx -> setDanger(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "value")))))
                .then(Commands.literal("spawn")
                        .then(Commands.argument("kind", StringArgumentType.word()).suggests(KINDS)
                                .executes(ctx -> spawn(ctx, false))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> spawn(ctx, true)))))
                .then(Commands.literal("event")
                        .then(Commands.literal("hunter_run")
                                .executes(ctx -> event(ctx, false))
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(ctx -> event(ctx, true)))))
                .then(Commands.literal("clear").executes(ctx -> clear(ctx.getSource()))));
    }

    private static int help(CommandSourceStack s) {
        String[] lines = {
                "/stalker danger [0-100]   - ver/cambiar el peligro (por defecto 50)",
                "/stalker spawn <hunter|stalker|seeker|hunter_run> [jugador]",
                "/stalker event hunter_run [jugador]   - cuenta atras y aparece (reintenta hasta lograrlo)",
                "/stalker clear   - elimina todos y cancela eventos"
        };
        for (String l : lines) s.sendSuccess(() -> Component.literal(l), false);
        return 1;
    }

    private static int showDanger(CommandSourceStack s) {
        int v = StalkerConfig.danger();
        s.sendSuccess(() -> Component.literal("Peligro actual: " + v + " / 100"), false);
        return v;
    }

    private static int setDanger(CommandSourceStack s, int v) {
        StalkerConfig.DANGER.set(v);
        try {
            StalkerConfig.SPEC.save();
        } catch (Exception ignored) {
            // el valor ya esta aplicado en memoria
        }
        s.sendSuccess(() -> Component.literal("Peligro ajustado a " + v + " / 100"), true);
        return v;
    }

    private static ServerPlayer playerArg(CommandContext<CommandSourceStack> ctx, boolean explicit)
            throws CommandSyntaxException {
        return explicit ? EntityArgument.getPlayer(ctx, "player") : ctx.getSource().getPlayerOrException();
    }

    private static int spawn(CommandContext<CommandSourceStack> ctx, boolean explicit) throws CommandSyntaxException {
        CommandSourceStack s = ctx.getSource();
        StalkerKind kind = StalkerKind.byId(StringArgumentType.getString(ctx, "kind"));
        if (kind == null) {
            s.sendFailure(Component.literal("Tipo desconocido. Usa: hunter, stalker, seeker, hunter_run"));
            return 0;
        }
        ServerPlayer p = playerArg(ctx, explicit);
        StalkerEntity e = StalkerSpawner.spawn(p, kind, false, 10.0, 18.0, 40);
        if (e == null) {
            s.sendFailure(Component.literal("No hay sitio para aparecer. Intenta de nuevo."));
            return 0;
        }
        s.sendSuccess(() -> Component.literal(kind.id + " aparecio cerca de " + p.getName().getString()), true);
        return 1;
    }

    private static int event(CommandContext<CommandSourceStack> ctx, boolean explicit) throws CommandSyntaxException {
        CommandSourceStack s = ctx.getSource();
        ServerPlayer p = playerArg(ctx, explicit);
        if (!StalkerDirector.startHunterRun(p)) {
            s.sendFailure(Component.literal("Ese jugador ya tiene un hunter_run activo."));
            return 0;
        }
        int secs = StalkerConfig.HUNTER_RUN_SECONDS.get();
        s.sendSuccess(() -> Component.literal("Evento hunter_run iniciado: contador en " + secs
                + " s. Si no puede aparecer, reintenta hasta lograrlo."), true);
        return 1;
    }

    private static int clear(CommandSourceStack s) {
        StalkerDirector.stopAll(s.getServer());
        int n = StalkerDirector.despawnAll(s.getServer());
        s.sendSuccess(() -> Component.literal("Eliminados " + n + " y eventos cancelados."), true);
        return n;
    }

    private StalkerCommand() {}
}
