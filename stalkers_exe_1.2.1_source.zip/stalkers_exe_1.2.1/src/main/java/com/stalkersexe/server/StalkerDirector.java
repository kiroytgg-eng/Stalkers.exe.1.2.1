package com.stalkersexe.server;

import com.stalkersexe.StalkersMod;
import com.stalkersexe.entity.StalkerEntity;
import com.stalkersexe.entity.StalkerKind;
import com.stalkersexe.registry.ModSounds;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Director: hace aparecer stalkers solos segun el peligro y gestiona el evento hunter_run
 * (cuenta atras acelerada + reintentos hasta que el Hunter Run realmente aparezca).
 */
@Mod.EventBusSubscriber(modid = StalkersMod.MODID)
public final class StalkerDirector {

    private enum Phase { COUNTDOWN, SPAWNING, CHASE }

    private static final class RunEvent {
        final UUID player;
        Phase phase = Phase.COUNTDOWN;
        int ticksLeft;
        int pulseCd;
        int retryCd;
        int attempts;
        UUID entity;

        RunEvent(UUID player, int ticks) {
            this.player = player;
            this.ticksLeft = ticks;
        }
    }

    private static final Map<UUID, RunEvent> RUNS = new HashMap<>();

    // ---------------- API ----------------

    /** Empieza el evento hunter_run para el jugador. false si ya tenia uno activo. */
    public static boolean startHunterRun(ServerPlayer p) {
        if (RUNS.containsKey(p.getUUID())) return false;
        RunEvent ev = new RunEvent(p.getUUID(), StalkerConfig.HUNTER_RUN_SECONDS.get() * 20);
        RUNS.put(p.getUUID(), ev);
        p.playNotifySound(ModSounds.get("hunt_run_warn"), SoundSource.HOSTILE, 1.0F, 1.0F);
        return true;
    }

    public static boolean hasRun(UUID id) {
        return RUNS.containsKey(id);
    }

    public static void stopAll(MinecraftServer server) {
        RUNS.clear();
    }

    public static int despawnAll(MinecraftServer server) {
        int n = 0;
        for (ServerLevel lvl : server.getAllLevels()) {
            java.util.List<Entity> found = new java.util.ArrayList<>();
            for (Entity e : lvl.getAllEntities()) {
                if (e instanceof StalkerEntity) found.add(e);
            }
            for (Entity e : found) {
                e.discard();
                n++;
            }
        }
        return n;
    }

    // ---------------- tick ----------------

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        tickRuns(server);

        if (server.getTickCount() % 20 == 0) {
            secondlyChecks(server);
        }
    }

    private static void tickRuns(MinecraftServer server) {
        for (Iterator<RunEvent> it = RUNS.values().iterator(); it.hasNext();) {
            RunEvent ev = it.next();
            ServerPlayer p = server.getPlayerList().getPlayer(ev.player);
            if (p == null || !p.isAlive()) {
                it.remove();
                continue;
            }
            switch (ev.phase) {
                case COUNTDOWN -> {
                    ev.ticksLeft--;
                    if (ev.ticksLeft % 20 == 0) showCounter(p, ev);
                    if (--ev.pulseCd <= 0) {
                        ev.pulseCd = Mth.clamp(ev.ticksLeft / 6, 10, 60); // mas rapido al acercarse el final
                        p.playNotifySound(ModSounds.get("pulse"), SoundSource.HOSTILE, 0.6F, 1.0F);
                    }
                    if (ev.ticksLeft <= 0) {
                        ev.phase = Phase.SPAWNING;
                        ev.retryCd = 0;
                    }
                }
                case SPAWNING -> {
                    // Se repite hasta que el Hunter Run realmente aparezca
                    if (ev.retryCd > 0) {
                        ev.retryCd--;
                    } else {
                        ev.attempts++;
                        StalkerEntity e = trySpawnRun(p, ev.attempts);
                        if (e != null) {
                            ev.entity = e.getUUID();
                            ev.phase = Phase.CHASE;
                            p.playNotifySound(ModSounds.get("hunt_run_warn"), SoundSource.HOSTILE, 1.0F, 1.0F);
                            p.playNotifySound(ModSounds.get("es_near"), SoundSource.HOSTILE, 1.0F, 1.0F);
                            p.displayClientMessage(Component.literal("HUNTER_RUN")
                                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
                        } else {
                            ev.retryCd = StalkerConfig.HUNTER_RUN_RETRY_TICKS.get();
                            p.displayClientMessage(Component.literal("...")
                                    .withStyle(ChatFormatting.DARK_RED), true);
                        }
                    }
                }
                case CHASE -> {
                    Entity ent = findEntity(server, ev.entity);
                    if (ent == null || !ent.isAlive()) it.remove();
                }
            }
        }
    }

    /** Intentos cada vez mas permisivos hasta que haya sitio. */
    private static StalkerEntity trySpawnRun(ServerPlayer p, int attempt) {
        double minD = Math.max(6.0, 20.0 - attempt);
        double maxD = Math.min(64.0, 30.0 + attempt * 2.0);
        boolean behind = attempt % 2 == 1 && attempt < 12;
        if (attempt > 20) {
            minD = 3.0;
            maxD = 12.0;
        }
        return StalkerSpawner.spawn(p, StalkerKind.HUNTER_RUN, behind, minD, maxD, 24);
    }

    private static Entity findEntity(MinecraftServer server, UUID id) {
        if (id == null) return null;
        for (ServerLevel lvl : server.getAllLevels()) {
            Entity e = lvl.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static void showCounter(ServerPlayer p, RunEvent ev) {
        int secs = (int) Math.ceil(ev.ticksLeft / 20.0);
        ChatFormatting color = secs <= 10 ? ChatFormatting.DARK_RED : (secs <= 30 ? ChatFormatting.RED : ChatFormatting.GRAY);
        p.displayClientMessage(Component.literal("HUNTER_RUN  " + secs).withStyle(color, ChatFormatting.BOLD), true);
    }

    // ---------------- cada segundo ----------------

    private static void secondlyChecks(MinecraftServer server) {
        double d = StalkerConfig.danger01();
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (!p.isAlive() || p.isCreative() || p.isSpectator()) continue;
            ServerLevel lvl = p.serverLevel();

            // Los Buscadores oyen que corres
            if (p.isSprinting()) NoiseTracker.record(lvl, p.position());

            if (d <= 0.0) continue;

            // hunter_run automatico
            if (StalkerConfig.AUTO_HUNTER_RUN.get() && !RUNS.containsKey(p.getUUID())) {
                double chance = 0.0005 + 0.0045 * d * d;
                if (lvl.random.nextDouble() < chance) startHunterRun(p);
            }

            if (!StalkerConfig.DIRECTOR_ENABLED.get()) continue;
            if (lvl.dimension() == Level.END) continue;

            int max = StalkerConfig.MAX_PER_PLAYER.get() + (int) (d * 3.0);
            AABB box = p.getBoundingBox().inflate(80.0);
            int near = 0;
            for (StalkerEntity e : lvl.getEntitiesOfClass(StalkerEntity.class, box)) {
                if (e.kind() != StalkerKind.HUNTER_RUN) near++;
            }
            if (near >= max) continue;

            boolean dark = lvl.getMaxLocalRawBrightness(p.blockPosition()) <= 7;
            double env = dark ? 1.0 : (lvl.isDay() ? 0.15 : 0.6);
            double chance = (0.004 + 0.03 * d) * env;
            if (lvl.random.nextDouble() >= chance) continue;

            StalkerKind kind = pickKind(lvl.random.nextInt(100));
            StalkerEntity e = StalkerSpawner.spawn(p, kind, true, 22.0, 36.0, 16);
            if (e != null) {
                p.playNotifySound(ModSounds.get("es_glitch"), SoundSource.HOSTILE, 0.4F, 1.0F);
            }
        }
    }

    private static StalkerKind pickKind(int roll) {
        if (roll < 40) return StalkerKind.HUNTER;
        if (roll < 70) return StalkerKind.STALKER;
        return StalkerKind.SEEKER;
    }

    private StalkerDirector() {}
}
