package com.stalkersexe.server;

import com.stalkersexe.StalkersMod;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Ruidos recientes (picar bloques, correr). Los Buscadores los siguen. */
@Mod.EventBusSubscriber(modid = StalkersMod.MODID)
public final class NoiseTracker {
    public record Noise(ResourceKey<Level> dim, Vec3 pos, long tick) {}

    private static final List<Noise> NOISES = new ArrayList<>();

    public static synchronized void record(Level level, Vec3 pos) {
        NOISES.add(new Noise(level.dimension(), pos, level.getGameTime()));
        if (NOISES.size() > 64) NOISES.remove(0);
    }

    public static synchronized Noise nearest(Level level, Vec3 from, double range) {
        long now = level.getGameTime();
        NOISES.removeIf(n -> now - n.tick() > 400 || now < n.tick());
        Noise best = null;
        double bestD = range * range;
        for (Noise n : NOISES) {
            if (!n.dim().equals(level.dimension())) continue;
            double d = n.pos().distanceToSqr(from);
            if (d < bestD) {
                bestD = d;
                best = n;
            }
        }
        return best;
    }

    @SubscribeEvent
    public static void onBreak(BlockEvent.BreakEvent e) {
        if (e.getPlayer() != null && e.getLevel() instanceof Level l) {
            record(l, Vec3.atCenterOf(e.getPos()));
        }
    }

    private NoiseTracker() {}
}
